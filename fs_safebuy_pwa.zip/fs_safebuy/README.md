# 🛡️ FS_SafeBuy — دليل التثبيت والنشر

## طريقة النشر على Vercel (مجانية — الأسهل والأسرع)

### الخطوة 1: تثبيت Node.js
- حمّل Node.js من: https://nodejs.org (اختر LTS)
- ثبّته وأعد تشغيل الجهاز

### الخطوة 2: رفع الملفات على GitHub
1. افتح https://github.com وأنشئ حساباً مجانياً
2. اضغط "New repository" واسمه `fs-safebuy`
3. ارفع مجلد المشروع كاملاً

### الخطوة 3: النشر على Vercel
1. افتح https://vercel.com وسجّل دخول بحساب GitHub
2. اضغط "Add New Project"
3. اختر مستودع `fs-safebuy`
4. اضغط Deploy ✅

### الخطوة 4: تثبيت التطبيق على الجوال
بعد النشر ستحصل على رابط مثل: `https://fs-safebuy.vercel.app`

**على iPhone:**
1. افتح الرابط في Safari
2. اضغط زر المشاركة (Share) ⬆️
3. اختر "Add to Home Screen"
4. اضغط Add — سيظهر أيقونة التطبيق على شاشتك الرئيسية ✅

**على Android:**
1. افتح الرابط في Chrome
2. ستظهر نافذة "Add to Home Screen" تلقائياً
3. أو اضغط ⋮ ثم "Add to Home Screen"

---

## تشغيل محلي للتطوير

```bash
cd fs_safebuy
npm install
npm start
```
سيفتح التطبيق على: http://localhost:3000

## بناء النسخة النهائية

```bash
npm run build
```
سينشئ مجلد `build/` جاهز للرفع على أي استضافة.

---

## هيكل المشروع

```
fs_safebuy/
├── public/
│   ├── index.html       ← صفحة HTML الرئيسية
│   ├── manifest.json    ← إعدادات PWA
│   ├── sw.js            ← Service Worker للعمل أوفلاين
│   ├── icon-192.png     ← أيقونة التطبيق
│   └── icon-512.png     ← أيقونة كبيرة
├── src/
│   ├── index.js         ← نقطة الدخول
│   └── App.js           ← التطبيق الكامل
├── package.json
└── README.md
```

---

## مميزات PWA

- ✅ يعمل أوفلاين (Service Worker)
- ✅ يُثبَّت على شاشة الرئيسية
- ✅ شاشة سبلاش عند الفتح
- ✅ يعمل بدون شريط المتصفح (Standalone)
- ✅ دعم كامل للغة العربية RTL
- ✅ متوافق مع iPhone وAndroid
